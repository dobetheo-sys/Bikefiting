import { useState, useRef, useCallback, useEffect } from 'react';
import { Video, Camera, Square, RotateCcw, Check, AlertTriangle, ChevronDown, ChevronUp } from 'lucide-react';

// posture-capture-flow.jsx
// Flux de capture réel (caméra du téléphone) pour les deux entrées du pipeline §2 du spec :
//   A. vidéo profil (angles articulaires)
//   B. photo frontale + étalonnage par 2 taps (pFSA)
//
// Ce composant s'arrête à la capture + étalonnage : il ne lance PAS de pose estimation
// ni de segmentation ici (ça vit dans capture-processing.ts / segmentation-integration.ts,
// pas exécutable dans ce rendu artifact). L'écran final affiche ce qui serait transmis
// au moteur, pas un résultat d'analyse.
//
// Non garanti dans ce contexte d'aperçu : l'accès caméra dépend des permissions de
// l'iframe d'artifact — s'il ne fonctionne pas ici, le même code fonctionnera intégré
// directement au domaine de l'app (contexte sécurisé standard, pas de restriction d'iframe).

const CHECKLISTS = {
  profile_video: [
    'Caméra fixe (support/trépied), vue de profil, dans l\u2019axe du vélo',
    'Cadrage : vélo + corps entier visibles',
    'Même réglage vélo qu\u2019à l\u2019essai précédent si tu compares',
    'Effort stable, plusieurs tours de pédalage complets pendant l\u2019enregistrement',
  ],
  frontal_photo: [
    'Caméra dans l\u2019axe du vélo, vue de face',
    'Recul d\u2019au moins 5 m (sinon la mesure de surface est faussée)',
    'Un repère de longueur connue visible (ex. largeur de cintre) pour l\u2019étalonnage',
    'Position immobile au moment de la photo',
  ],
};

function formatElapsed(ms) {
  const s = Math.floor(ms / 1000);
  const cs = Math.floor((ms % 1000) / 100);
  return `${String(s).padStart(2, '0')}.${cs}s`;
}

export default function PostureCaptureFlow() {
  const [screen, setScreen] = useState('intro'); // intro | camera | review | calibrate | done
  const [mode, setMode] = useState(null);
  const [error, setError] = useState(null);
  const [recording, setRecording] = useState(false);
  const [elapsedMs, setElapsedMs] = useState(0);
  const [capturedUrl, setCapturedUrl] = useState(null);
  const [capturedMeta, setCapturedMeta] = useState(null);
  const [checklistOpen, setChecklistOpen] = useState(true);
  const [taps, setTaps] = useState([]);
  const [refLengthCm, setRefLengthCm] = useState('40');
  const [tilt, setTilt] = useState(null);

  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const chunksRef = useRef([]);
  const timerRef = useRef(null);
  const startedAtRef = useRef(0);

  const stopStream = useCallback(() => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
  }, []);

  useEffect(() => () => { stopStream(); clearInterval(timerRef.current); }, [stopStream]);

  useEffect(() => {
    function onOrientation(e) {
      if (typeof e.gamma === 'number') setTilt(e.gamma);
    }
    window.addEventListener('deviceorientation', onOrientation);
    return () => window.removeEventListener('deviceorientation', onOrientation);
  }, []);

  const startCamera = useCallback(async (m) => {
    setError(null);
    setMode(m);
    setChecklistOpen(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });
      streamRef.current = stream;
      setScreen('camera');
      // srcObject assigné après le rendu (voir effect ci-dessous)
    } catch (e) {
      const msg =
        e && e.name === 'NotAllowedError'
          ? 'Accès caméra refusé. Autorise la caméra dans les réglages du navigateur pour continuer.'
          : 'Caméra inaccessible sur cet appareil ou dans ce contexte d\u2019aperçu.';
      setError(msg);
      setScreen('camera');
    }
  }, []);

  useEffect(() => {
    if (screen === 'camera' && videoRef.current && streamRef.current) {
      videoRef.current.srcObject = streamRef.current;
      videoRef.current.play().catch(() => {});
    }
  }, [screen]);

  const startRecording = () => {
    if (!streamRef.current) return;
    chunksRef.current = [];
    const mimeType = window.MediaRecorder && MediaRecorder.isTypeSupported('video/webm;codecs=vp9')
      ? 'video/webm;codecs=vp9'
      : 'video/webm';
    const mr = new MediaRecorder(streamRef.current, { mimeType });
    mr.ondataavailable = (e) => { if (e.data.size > 0) chunksRef.current.push(e.data); };
    mr.onstop = () => {
      const blob = new Blob(chunksRef.current, { type: mimeType });
      setCapturedUrl(URL.createObjectURL(blob));
      setCapturedMeta({ type: 'video', sizeKb: Math.round(blob.size / 1024), durationMs: elapsedMs });
      setScreen('review');
    };
    mediaRecorderRef.current = mr;
    mr.start();
    setRecording(true);
    setElapsedMs(0);
    startedAtRef.current = Date.now();
    timerRef.current = setInterval(() => setElapsedMs(Date.now() - startedAtRef.current), 100);
  };

  const stopRecording = () => {
    mediaRecorderRef.current?.stop();
    setRecording(false);
    clearInterval(timerRef.current);
  };

  const capturePhoto = () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext('2d').drawImage(video, 0, 0);
    canvas.toBlob((blob) => {
      setCapturedUrl(URL.createObjectURL(blob));
      setCapturedMeta({ type: 'photo', sizeKb: Math.round(blob.size / 1024), width: canvas.width, height: canvas.height });
      setTaps([]);
      setScreen('calibrate');
    }, 'image/jpeg', 0.92);
  };

  const retake = () => {
    setCapturedUrl(null);
    setCapturedMeta(null);
    setTaps([]);
    setScreen('camera');
  };

  const handleCalibrationTap = (e) => {
    if (taps.length >= 2 || !canvasRef.current) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * canvasRef.current.width;
    const y = ((e.clientY - rect.top) / rect.height) * canvasRef.current.height;
    setTaps((prev) => [...prev, { x, y }]);
  };

  const pixelLength = taps.length === 2 ? Math.hypot(taps[1].x - taps[0].x, taps[1].y - taps[0].y) : null;
  const cmPerPixel = pixelLength && refLengthCm ? Number(refLengthCm) / pixelLength : null;

  const finish = () => {
    stopStream();
    setScreen('done');
  };

  const startOver = () => {
    setCapturedUrl(null);
    setCapturedMeta(null);
    setTaps([]);
    setMode(null);
    setError(null);
    setScreen('intro');
  };

  const isLevelOk = tilt === null || Math.abs(tilt) < 4;

  return (
    <div className="w-full h-full min-h-screen bg-neutral-950 text-neutral-100 flex flex-col" style={{ fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif' }}>
      <canvas ref={canvasRef} className="hidden" />

      {screen === 'intro' && (
        <div className="flex-1 flex flex-col justify-center px-6 py-10 max-w-md mx-auto w-full">
          <div className="mb-8">
            <div className="text-xs tracking-widest text-amber-400 uppercase mb-2" style={{ fontFamily: 'ui-monospace, "SF Mono", Menlo, monospace' }}>
              Capture posture · aéro
            </div>
            <h1 className="text-2xl font-semibold text-neutral-100 leading-snug">Choisis ta capture</h1>
            <p className="text-neutral-400 text-sm mt-1">Deux entrées nécessaires pour scorer un essai.</p>
          </div>

          <button
            onClick={() => startCamera('profile_video')}
            className="group text-left rounded-lg border border-neutral-800 bg-neutral-900 p-4 mb-3 hover:border-amber-400/50 focus:outline-none focus:ring-2 focus:ring-amber-400 transition-colors"
          >
            <div className="flex items-center gap-3">
              <Video className="w-5 h-5 text-amber-400 shrink-0" />
              <div>
                <div className="font-medium text-neutral-100">Vidéo profil</div>
                <div className="text-xs text-neutral-400 mt-0.5">Angles articulaires sur le cycle de pédalage</div>
              </div>
            </div>
          </button>

          <button
            onClick={() => startCamera('frontal_photo')}
            className="group text-left rounded-lg border border-neutral-800 bg-neutral-900 p-4 hover:border-cyan-400/50 focus:outline-none focus:ring-2 focus:ring-cyan-400 transition-colors"
          >
            <div className="flex items-center gap-3">
              <Camera className="w-5 h-5 text-cyan-400 shrink-0" />
              <div>
                <div className="font-medium text-neutral-100">Photo frontale</div>
                <div className="text-xs text-neutral-400 mt-0.5">Surface frontale (pFSA), avec étalonnage</div>
              </div>
            </div>
          </button>

          <p className="text-neutral-500 text-xs mt-8 leading-relaxed">
            L\u2019étalonnage de la photo frontale se fait par 2 points touchés directement sur l\u2019image, pas de repère automatique en V1.
          </p>
        </div>
      )}

      {screen === 'camera' && (
        <div className="flex-1 relative flex flex-col">
          {error ? (
            <div className="flex-1 flex flex-col items-center justify-center px-6 text-center">
              <AlertTriangle className="w-8 h-8 text-red-400 mb-3" />
              <p className="text-neutral-200 text-sm max-w-xs">{error}</p>
              <button onClick={startOver} className="mt-6 text-sm text-amber-400 underline underline-offset-4 focus:outline-none focus:ring-2 focus:ring-amber-400 rounded">
                Retour
              </button>
            </div>
          ) : (
            <>
              <div className="relative flex-1 overflow-hidden bg-black">
                <video ref={videoRef} playsInline muted className="w-full h-full object-cover" />

                {/* Réticule — élément signature : alignement optique + niveau */}
                <div className="absolute inset-0 pointer-events-none">
                  <div className="absolute left-1/2 top-0 bottom-0 w-px" style={{ background: 'rgba(232,230,225,0.18)', transform: 'translateX(-0.5px)' }} />
                  <div className="absolute top-1/2 left-0 right-0 h-px" style={{ background: 'rgba(232,230,225,0.18)', transform: 'translateY(-0.5px)' }} />
                  <div
                    className="absolute left-1/2 top-1/2 w-14 h-14 rounded-full border"
                    style={{ borderColor: 'rgba(232,230,225,0.35)', transform: 'translate(-50%,-50%)' }}
                  />
                  {/* Indicateur de niveau (best-effort, se cache si le capteur n'est pas dispo) */}
                  {tilt !== null && (
                    <div className="absolute top-4 left-1/2 -translate-x-1/2 flex items-center gap-2 px-2.5 py-1 rounded-full bg-black/50" style={{ fontFamily: 'ui-monospace, monospace' }}>
                      <div className={`w-1.5 h-1.5 rounded-full ${isLevelOk ? 'bg-cyan-400' : 'bg-red-400'}`} />
                      <span className="text-[11px] text-neutral-200">{isLevelOk ? 'niveau ok' : `inclinaison ${tilt.toFixed(0)}°`}</span>
                    </div>
                  )}
                </div>

                {recording && (
                  <div className="absolute top-4 right-4 flex items-center gap-2 px-2.5 py-1 rounded-full bg-black/60">
                    <span className="w-2 h-2 rounded-full bg-red-400 animate-pulse" />
                    <span className="text-xs text-neutral-100" style={{ fontFamily: 'ui-monospace, monospace' }}>{formatElapsed(elapsedMs)}</span>
                  </div>
                )}
              </div>

              {/* Checklist repliable */}
              <div className="bg-neutral-900 border-t border-neutral-800">
                <button
                  onClick={() => setChecklistOpen((v) => !v)}
                  className="w-full flex items-center justify-between px-4 py-2.5 text-xs text-neutral-400 focus:outline-none"
                >
                  <span className="tracking-wide uppercase" style={{ fontFamily: 'ui-monospace, monospace' }}>
                    Checklist · {mode === 'profile_video' ? 'vidéo profil' : 'photo frontale'}
                  </span>
                  {checklistOpen ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronUp className="w-3.5 h-3.5" />}
                </button>
                {checklistOpen && (
                  <ul className="px-4 pb-3 space-y-1.5">
                    {CHECKLISTS[mode].map((item, i) => (
                      <li key={i} className="text-xs text-neutral-300 flex gap-2">
                        <span className="text-amber-400 shrink-0">·</span>
                        {item}
                      </li>
                    ))}
                  </ul>
                )}
              </div>

              {/* Contrôles */}
              <div className="bg-black px-6 py-5 flex items-center justify-center">
                {mode === 'profile_video' ? (
                  recording ? (
                    <button
                      onClick={stopRecording}
                      className="w-16 h-16 rounded-full bg-red-500 flex items-center justify-center focus:outline-none focus:ring-2 focus:ring-red-300 ring-offset-2 ring-offset-black"
                      aria-label="Arrêter l'enregistrement"
                    >
                      <Square className="w-5 h-5 text-white" fill="white" />
                    </button>
                  ) : (
                    <button
                      onClick={startRecording}
                      className="w-16 h-16 rounded-full border-4 border-neutral-200 flex items-center justify-center focus:outline-none focus:ring-2 focus:ring-amber-400 ring-offset-2 ring-offset-black"
                      aria-label="Démarrer l'enregistrement"
                    >
                      <span className="w-12 h-12 rounded-full bg-red-500" />
                    </button>
                  )
                ) : (
                  <button
                    onClick={capturePhoto}
                    className="w-16 h-16 rounded-full border-4 border-neutral-200 flex items-center justify-center focus:outline-none focus:ring-2 focus:ring-cyan-400 ring-offset-2 ring-offset-black"
                    aria-label="Prendre la photo"
                  >
                    <span className="w-12 h-12 rounded-full bg-neutral-100" />
                  </button>
                )}
              </div>
            </>
          )}
        </div>
      )}

      {screen === 'review' && (
        <div className="flex-1 flex flex-col">
          <div className="flex-1 bg-black flex items-center justify-center">
            <video src={capturedUrl} controls playsInline className="max-w-full max-h-full" />
          </div>
          <div className="bg-neutral-900 border-t border-neutral-800 px-6 py-4 space-y-3">
            <div className="text-xs text-neutral-400" style={{ fontFamily: 'ui-monospace, monospace' }}>
              {capturedMeta && `${(capturedMeta.durationMs / 1000).toFixed(1)}s · ${capturedMeta.sizeKb} Ko`}
            </div>
            <div className="flex gap-3">
              <button onClick={retake} className="flex-1 flex items-center justify-center gap-2 py-3 rounded-lg border border-neutral-700 text-neutral-200 focus:outline-none focus:ring-2 focus:ring-amber-400">
                <RotateCcw className="w-4 h-4" /> Reprendre
              </button>
              <button onClick={finish} className="flex-1 flex items-center justify-center gap-2 py-3 rounded-lg bg-amber-400 text-neutral-950 font-medium focus:outline-none focus:ring-2 focus:ring-amber-200">
                <Check className="w-4 h-4" /> Valider
              </button>
            </div>
          </div>
        </div>
      )}

      {screen === 'calibrate' && (
        <div className="flex-1 flex flex-col">
          <div className="px-6 py-3 bg-neutral-900 border-b border-neutral-800">
            <p className="text-sm text-neutral-200">
              Touche 2 points correspondant à une longueur connue (ex. les deux extrémités du cintre).
            </p>
            <p className="text-xs text-neutral-500 mt-1">{taps.length}/2 points placés</p>
          </div>

          <div className="flex-1 relative bg-black flex items-center justify-center overflow-hidden">
            <img
              src={capturedUrl}
              alt="Photo frontale capturée"
              onClick={handleCalibrationTap}
              className="max-w-full max-h-full cursor-crosshair"
            />
            {/* Marqueurs de taps, positionnés en % relatif à l'image affichée */}
            {capturedMeta && taps.map((t, i) => (
              <div
                key={i}
                className="absolute w-3 h-3 rounded-full bg-cyan-400 border-2 border-neutral-950 pointer-events-none"
                style={{
                  left: `${(t.x / capturedMeta.width) * 100}%`,
                  top: `${(t.y / capturedMeta.height) * 100}%`,
                  transform: 'translate(-50%,-50%)',
                }}
              />
            ))}
          </div>

          <div className="bg-neutral-900 border-t border-neutral-800 px-6 py-4 space-y-3">
            <label className="flex items-center gap-3 text-sm text-neutral-200">
              Longueur réelle du repère (cm)
              <input
                type="number"
                value={refLengthCm}
                onChange={(e) => setRefLengthCm(e.target.value)}
                className="w-20 bg-neutral-800 border border-neutral-700 rounded px-2 py-1 text-neutral-100 focus:outline-none focus:ring-2 focus:ring-cyan-400"
              />
            </label>

            {pixelLength && (
              <div className="text-xs text-neutral-400" style={{ fontFamily: 'ui-monospace, monospace' }}>
                {pixelLength.toFixed(0)}px mesurés · {cmPerPixel?.toFixed(3)} cm/px
              </div>
            )}

            <div className="flex gap-3">
              <button onClick={retake} className="flex-1 flex items-center justify-center gap-2 py-3 rounded-lg border border-neutral-700 text-neutral-200 focus:outline-none focus:ring-2 focus:ring-amber-400">
                <RotateCcw className="w-4 h-4" /> Reprendre
              </button>
              <button
                onClick={finish}
                disabled={taps.length < 2}
                className="flex-1 flex items-center justify-center gap-2 py-3 rounded-lg bg-cyan-400 text-neutral-950 font-medium disabled:opacity-30 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-cyan-200"
              >
                <Check className="w-4 h-4" /> Valider l'étalonnage
              </button>
            </div>
          </div>
        </div>
      )}

      {screen === 'done' && (
        <div className="flex-1 flex flex-col justify-center px-6 py-10 max-w-md mx-auto w-full">
          <div className="text-xs tracking-widest text-cyan-400 uppercase mb-2" style={{ fontFamily: 'ui-monospace, monospace' }}>
            Essai prêt
          </div>
          <h1 className="text-xl font-semibold mb-4">Capture enregistrée</h1>

          <div className="rounded-lg border border-neutral-800 bg-neutral-900 p-4 mb-6" style={{ fontFamily: 'ui-monospace, monospace' }}>
            <pre className="text-xs text-neutral-300 whitespace-pre-wrap leading-relaxed">
{JSON.stringify(
  {
    mode,
    ...(capturedMeta || {}),
    calibration: pixelLength ? { pixelLength: Math.round(pixelLength), realLengthCm: Number(refLengthCm) } : undefined,
  },
  null,
  2
)}
            </pre>
          </div>

          <p className="text-neutral-500 text-xs mb-6 leading-relaxed">
            Cette capture correspond à l'entrée attendue par le moteur (posture-aero-engine.ts) une fois passée par
            l'extraction d'angles / pFSA — non exécutée dans cet aperçu.
          </p>

          <button onClick={startOver} className="py-3 rounded-lg border border-neutral-700 text-neutral-200 focus:outline-none focus:ring-2 focus:ring-amber-400">
            Nouvel essai
          </button>
        </div>
      )}
    </div>
  );
}
